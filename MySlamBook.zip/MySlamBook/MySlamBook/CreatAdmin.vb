﻿Imports MySlamBook.Manu
Public Class CreatAdmin

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Manu.Show()
        Me.Hide()
    End Sub
End Class