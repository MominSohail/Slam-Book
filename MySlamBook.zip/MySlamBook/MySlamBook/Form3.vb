﻿Imports System.Data.OleDb
Imports MySlamBook.Form4
Imports MySlamBook.Form2
Public Class Form3
    Dim conn As New OleDbConnection(" Provider=Microsoft.ACE.OLEDB.12.0;Data Source= C:\Program Files\SlamBookAccess.accdb ")
    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged

    End Sub

    Private Sub Form3_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.Hide()
        Form4.Show()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Me.Hide()
        Form2.Show()
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Dim str As String = "insert into New_Friend values('" & TextBox1.Text & "','" & TextBox2.Text & "','" & DateTimePicker1.Text & "','" & Convert.ToSingle(TextBox4.Text) & "','" & Convert.ToSingle(TextBox5.Text) & "','" & TextBox6.Text & "','" & TextBox7.Text & "','" & TextBox8.Text & "','" & ComboBox1.Text & "','" & TextBox9.Text & "')"

        If Not ConnectionState.Open Then
            conn.Open()
        End If

        Dim cmd As New OleDbCommand(str, conn)
        cmd.ExecuteNonQuery()
        MessageBox.Show("Record Saved")
        conn.Close()
    End Sub
End Class