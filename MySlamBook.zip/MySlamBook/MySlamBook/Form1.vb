﻿
Imports MySlamBook.LogInF
Imports MySlamBook.Form2
Public Class Form1

    Dim i As Integer
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Timer1.Start()
        Label1.Visible = False
        Label2.Visible = False
        Label3.Visible = False
        Label4.Visible = False
        PictureBox1.Visible = False
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        i = i + 1 Mod 100
        If i = 1 Then
            Label1.Visible = True
            Label2.Visible = False
            Label3.Visible = False
            Label4.Visible = False
        End If
        If i = 2 Then
            Label1.Visible = True
            Label2.Visible = True
            Label3.Visible = False
            Label4.Visible = False
        End If
        If i = 3 Then
            Label1.Visible = True
            Label2.Visible = True
            Label3.Visible = True
            Label4.Visible = False
        End If
        If i = 4 Then
            Label1.Visible = True
            Label2.Visible = True
            Label3.Visible = True
            Label4.Visible = True
            PictureBox1.Show()

        End If
        If i = 5 Then
            PictureBox1.Show()
        End If
        If i = 6 Then
            PictureBox1.Show()
        End If
        If i = 7 Then
            PictureBox1.Show()
        End If
        If i = 8 Then
            PictureBox1.Show()
        End If
        If i = 9 Then
            PictureBox1.Show()
        End If
        If i = 10 Then
            PictureBox1.Show()
        End If
        If i = 11 Then

            Timer1.Stop()
            Me.Hide()

            Form2.Show()
        End If
    End Sub

    Private Sub Label4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label4.Click

    End Sub

    Private Sub Label3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label3.Click

    End Sub

    Private Sub Label2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label2.Click

    End Sub

    Private Sub Label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label1.Click

    End Sub

    Private Sub PictureBox1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox1.Click

    End Sub
End Class
