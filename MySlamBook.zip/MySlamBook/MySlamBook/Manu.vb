﻿Imports MySlamBook.Form3
Imports MySlamBook.Form5
Imports MySlamBook.Form2
Imports MySlamBook.CreatAdmin
Imports MySlamBook.ChangePassword
Imports MySlamBook.Show1
Public Class Manu

    Private Sub OvalShape1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OvalShape1.Click
        Form3.Show()
    Me.Hide()
    End Sub
    Private Sub OvalShape1_MouseEnter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OvalShape1.MouseEnter
        OvalShape1.Anchor = AnchorStyles.None
        Me.OvalShape1.Size = New System.Drawing.Size(200, 100)
    End Sub
    Private Sub OvalShape1_MouseLeave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OvalShape1.MouseLeave
        Me.OvalShape1.Size = New System.Drawing.Size(160, 80)
    End Sub






    Private Sub OvalShape2_MouseEnter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OvalShape2.MouseEnter
        OvalShape2.Anchor = AnchorStyles.None
        Me.OvalShape2.Size = New System.Drawing.Size(200, 100)
    End Sub
    Private Sub OvalShape2_MouseLeave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OvalShape2.MouseLeave
        Me.OvalShape2.Size = New System.Drawing.Size(164, 66)
    End Sub
    Private Sub RectangleShape1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Form5.Show()
        Me.Hide()
    End Sub

    Private Sub OvalShape2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OvalShape2.Click
        CreatAdmin.Show()
        Me.Hide()
    End Sub

    Private Sub Manu_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

   

    Private Sub OvalShape3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OvalShape3.Click
        ChangePassword.Show()
        Me.Hide()
    End Sub


    Private Sub OvalShape3_MouseEnter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OvalShape3.MouseEnter
        OvalShape3.Anchor = AnchorStyles.None
        Me.OvalShape3.Size = New System.Drawing.Size(200, 100)
    End Sub
    Private Sub OvalShape3_MouseLeave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OvalShape3.MouseLeave
        Me.OvalShape3.Size = New System.Drawing.Size(140, 61)
    End Sub









    Private Sub OvalShape4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OvalShape4.Click
        Me.Hide()
        Show1.Show()

    End Sub

    Private Sub OvalShape4_MouseEnter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OvalShape4.MouseEnter
        OvalShape4.Anchor = AnchorStyles.None
        Me.OvalShape4.Size = New System.Drawing.Size(200, 100)
    End Sub
    Private Sub OvalShape4_MouseLeave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OvalShape4.MouseLeave
        Me.OvalShape4.Size = New System.Drawing.Size(129, 75)
    End Sub

    Private Sub OvalShape5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OvalShape5.Click
        Application.Exit()
    End Sub
    Private Sub OvalShape5_MouseEnter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OvalShape5.MouseEnter
        OvalShape5.Anchor = AnchorStyles.None
        Me.OvalShape5.Size = New System.Drawing.Size(175, 80)
    End Sub
    Private Sub OvalShape5_MouseLeave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OvalShape5.MouseLeave
        Me.OvalShape5.Size = New System.Drawing.Size(112, 50)
    End Sub
End Class