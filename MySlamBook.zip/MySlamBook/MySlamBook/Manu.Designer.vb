﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Manu
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.ShapeContainer1 = New Microsoft.VisualBasic.PowerPacks.ShapeContainer()
        Me.OvalShape5 = New Microsoft.VisualBasic.PowerPacks.OvalShape()
        Me.OvalShape4 = New Microsoft.VisualBasic.PowerPacks.OvalShape()
        Me.OvalShape3 = New Microsoft.VisualBasic.PowerPacks.OvalShape()
        Me.OvalShape2 = New Microsoft.VisualBasic.PowerPacks.OvalShape()
        Me.OvalShape1 = New Microsoft.VisualBasic.PowerPacks.OvalShape()
        Me.SuspendLayout()
        '
        'ShapeContainer1
        '
        Me.ShapeContainer1.Location = New System.Drawing.Point(0, 0)
        Me.ShapeContainer1.Margin = New System.Windows.Forms.Padding(0)
        Me.ShapeContainer1.Name = "ShapeContainer1"
        Me.ShapeContainer1.Shapes.AddRange(New Microsoft.VisualBasic.PowerPacks.Shape() {Me.OvalShape5, Me.OvalShape4, Me.OvalShape3, Me.OvalShape2, Me.OvalShape1})
        Me.ShapeContainer1.Size = New System.Drawing.Size(1319, 636)
        Me.ShapeContainer1.TabIndex = 0
        Me.ShapeContainer1.TabStop = False
        '
        'OvalShape5
        '
        Me.OvalShape5.BackgroundImage = Global.MySlamBook.My.Resources.Resources.ManuExit
        Me.OvalShape5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.OvalShape5.BorderColor = System.Drawing.Color.Transparent
        Me.OvalShape5.Location = New System.Drawing.Point(1080, 94)
        Me.OvalShape5.Name = "OvalShape5"
        Me.OvalShape5.Size = New System.Drawing.Size(112, 50)
        '
        'OvalShape4
        '
        Me.OvalShape4.BackgroundImage = Global.MySlamBook.My.Resources.Resources.ManuMyFriends
        Me.OvalShape4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.OvalShape4.BorderColor = System.Drawing.Color.Transparent
        Me.OvalShape4.Location = New System.Drawing.Point(439, 173)
        Me.OvalShape4.Name = "OvalShape4"
        Me.OvalShape4.Size = New System.Drawing.Size(129, 75)
        '
        'OvalShape3
        '
        Me.OvalShape3.BackgroundImage = Global.MySlamBook.My.Resources.Resources.ManuAbout
        Me.OvalShape3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.OvalShape3.BorderStyle = System.Drawing.Drawing2D.DashStyle.Custom
        Me.OvalShape3.Location = New System.Drawing.Point(857, 116)
        Me.OvalShape3.Name = "OvalShape3"
        Me.OvalShape3.Size = New System.Drawing.Size(140, 61)
        '
        'OvalShape2
        '
        Me.OvalShape2.BackgroundImage = Global.MySlamBook.My.Resources.Resources.ManuAdmin
        Me.OvalShape2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.OvalShape2.BorderStyle = System.Drawing.Drawing2D.DashStyle.Custom
        Me.OvalShape2.Location = New System.Drawing.Point(600, 112)
        Me.OvalShape2.Name = "OvalShape2"
        Me.OvalShape2.Size = New System.Drawing.Size(164, 66)
        '
        'OvalShape1
        '
        Me.OvalShape1.AccessibleRole = System.Windows.Forms.AccessibleRole.Window
        Me.OvalShape1.BackColor = System.Drawing.Color.Transparent
        Me.OvalShape1.BackgroundImage = Global.MySlamBook.My.Resources.Resources.ManuFreind
        Me.OvalShape1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.OvalShape1.BorderStyle = System.Drawing.Drawing2D.DashStyle.Custom
        Me.OvalShape1.Location = New System.Drawing.Point(202, 156)
        Me.OvalShape1.Name = "OvalShape1"
        Me.OvalShape1.Size = New System.Drawing.Size(160, 80)
        '
        'Manu
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.MySlamBook.My.Resources.Resources.Manu
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(1319, 636)
        Me.Controls.Add(Me.ShapeContainer1)
        Me.Name = "Manu"
        Me.Text = "Manu"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents ShapeContainer1 As Microsoft.VisualBasic.PowerPacks.ShapeContainer
    Friend WithEvents OvalShape1 As Microsoft.VisualBasic.PowerPacks.OvalShape
    Friend WithEvents OvalShape2 As Microsoft.VisualBasic.PowerPacks.OvalShape
    Friend WithEvents OvalShape3 As Microsoft.VisualBasic.PowerPacks.OvalShape
    Friend WithEvents OvalShape4 As Microsoft.VisualBasic.PowerPacks.OvalShape
    Friend WithEvents OvalShape5 As Microsoft.VisualBasic.PowerPacks.OvalShape
End Class
