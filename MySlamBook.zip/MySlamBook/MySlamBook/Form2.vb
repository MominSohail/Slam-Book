﻿Imports MySlamBook.Form3
Imports MySlamBook.Form5
Imports MySlamBook.Manu
Public Class Form2

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Manu.Show()
        Me.Hide()
    End Sub
End Class